const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const path = require('path');
const { error } = require('console');
const port = 3000; 
// 这是固定的端口，最好不要修改

const db = mysql.createConnection({
    host: 'localhost',
    user: 'app_user_music',
    password: 'Xqt2212937',
    database: 'music_player' //注意在 SCHEMAS 确认
});
// 1. 此处修改数据库的相关配置
// 2. 根据需求 create table

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL connected...');
});

app.use(cors());

app.use(bodyParser.json());

app.get('/getMusicList',(req,res)=>{
    const sql = 'select * from music_list';
    db.query(sql,(err,result)=>{
        if(err){
            console.log("Error:", err);
            res.status(500).send({error : 'error'})
        }
        res.json({ searchResult : result })
    })
  })

app.get('/getLikeList',(req,res)=>{
    const username = req.query.username;
    const sql = 'select * from user_like where u_username=?';
    db.query(sql,[username],(err,result)=>{
    if(err){
        console.log("Error:", err);
        res.status(500).send({error : 'error'})
    }
    res.json({ searchResult : result })
    })
})
// 插入操作
app.post('/addLike', (req, res) => {
    const { like_id, u_username } = req.body;
    const sql = 'INSERT INTO user_like (u_username,like_id ) VALUES (?, ?)';
    db.query(sql, [u_username,like_id ], (err, result) => {
      if (err) {
        console.log('数据库插入错误:', err);
        res.status(500).send({ error: '数据库插入错误' });
      } else {
        res.status(200).send('成功插入');
      }
    });
  });
// 删除操作
app.delete('/deleteLike', (req, res) => {
    const { like_id, u_username } = req.body;
    const sql = 'DELETE FROM user_like WHERE like_id = ? AND u_username = ?';
    db.query(sql, [like_id, u_username], (err, result) => {
      if (err) {
        console.log('数据库删除错误:', err);
        res.status(500).send({ error: '数据库删除错误' });
      } else {
        res.status(200).send('成功删除');
      }
    });
});
app.delete('/clearLike', (req, res) => {
    const u_username = req.body.u_username; // 从请求体中获取用户名
    const sql = 'DELETE FROM user_like WHERE u_username = ?';
    db.query(sql, [u_username], (err, result) => {
      if (err) {
        console.log('数据库删除错误:', err);
        res.status(500).send({ error: '数据库删除错误' });
      } else {
        res.status(200).send('成功删除');
      }
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
// 启动服务器