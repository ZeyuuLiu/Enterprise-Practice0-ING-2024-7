const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const path = require('path');
const port = 3001;

const db = mysql.createConnection({
    host: 'localhost',
    user: 'app_user_login', // 数据库用户名
    password: 'Xqt2212937', // 数据库密码
    database: 'music_player' // 数据库名
});
// 设置数据库连接相关配置

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL connected...');
});
// 连接数据库

app.use(cors());
app.use(bodyParser.json());


app.post('/loginuser', (req, res) => {
    const { username, password } = req.body;
    const SQL = 'SELECT * FROM user_login WHERE u_username = ? AND u_password = ?';
    const SQL_LOG = 'INSERT INTO user_logs (u_username, l_type, l_description) VALUES (?, "LOGIN", "User login")';
    // 构建 SQL 查询语句
    
    db.query(SQL, [username, password], (err, result) => {
        if (err) {
            res.status(500).send({ error: 'Failed to save reservation' });
            return;
        }
        else if (result.length > 0) { // 查询成功处理
            res.json({ success: true, result: result, username: username, password: password });

            
            db.query(SQL_LOG, [username], (err, result) => {
                if (err) {
                    res.status(500).send({ error: 'Failed to save reservation' });
                    return;
                }
            });
            // 记录登录日志

        }
        else { // 如果查询不到结果
            res.status(401).json({ success: false, message: 'Invalid username or password' });
        }
    });
    // 执行查询

});
// 处理用户登录请求


app.post('/addUser', (req, res) => {
    const { username, password, userEmail } = req.body;

    
    const SQL_USER = 'INSERT INTO user_login (u_username, u_password) VALUES (?, ?)';
    const SQL_EMAIL = 'INSERT INTO user_email (u_username, u_email) VALUES (?, ?)';
    // 插入用户数据的 SQL 语句
    
    db.beginTransaction((err) => {
        if (err) {
            res.status(500).send({ error: '注册失败' });
            return;
        }

        
        db.query(SQL_USER, [username, password], (err, result) => {
            if (err) {
                return db.rollback(() => {
                    res.status(500).send({ error: '用户名或密码注册失败' });
                });
            }

            
            db.query(SQL_EMAIL, [username, userEmail], (err, result) => {
                if (err) {
                    return db.rollback(() => {
                        res.status(500).send({ error: '邮箱注册失败' });
                    });
                }
                db.commit((err) => {
                    if (err) {
                        return db.rollback(() => {
                            res.status(500).send({ error: 'Failed to commit transaction' });
                        });
                    }
                    res.json({ success: true, data: result, username: username, userEmail: userEmail });
                });
                // 提交事务
                
            });
            // 执行第二个插入操作

        });
        // 执行第一个插入操作

    });
    // 开始事务处理

});
// 处理用户注册请求

app.put('/updateUser', (req, res) => {
    const { username, password, useremail } = req.body;
    const SQL = 'UPDATE user_login SET u_password = ? WHERE u_username IN (SELECT u_username FROM user_email WHERE u_username = ? AND u_email = ?)';
    // 构建更新用户信息的 SQL 语句
    
    db.query(SQL, [password, username, useremail], (err, result) => {
        if (err) {
            res.status(404).send({ error: '更新失败' })
            return;
        }
        res.json({ success: true, data: result, UserName: username, newPassWord: password, userEmail: useremail })
    })
    // 执行更新操作

})
// 处理更新用户信息请求

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
// 启动服务器监听指定端口